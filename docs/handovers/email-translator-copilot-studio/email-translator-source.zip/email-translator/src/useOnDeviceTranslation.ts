import {useEffect,useMemo,useRef,useState} from 'react';
import type {Email} from './email';
import {nativeTranslator,detectSourceLanguage,openTranslator,translateField,destroy,abortable,type Availability,type LocalTranslator} from './on-device';

type Options={email:Email;changes:Record<string,string>;target:string;apply:(id:string,value:string,expected:string|undefined)=>void};
export function useOnDeviceTranslation(options:Options) {
  const latest=useRef(options);latest.current=options;
  const detectedSource=useMemo(()=>detectSourceLanguage(options.email),[options.email]);
  const [source,setSource]=useState(detectedSource);
  const [state,setState]=useState<{key:string;value:Availability|'checking'|'unsupported'|'choose'|'error'}>({key:'',value:'checking'});
  const [busy,setBusy]=useState(false);
  const [status,setStatus]=useState('');
  const [progress,setProgress]=useState<number|null>(null);
  const [checkVersion,setCheckVersion]=useState(0);
  const job=useRef<{controller:AbortController;session?:LocalTranslator}|undefined>(undefined);
  const api=nativeTranslator();
  const pairKey=`${source}\0${options.target}`;
  const stop=()=>{job.current?.controller.abort();destroy(job.current?.session);job.current=undefined;};
  const cancel=(silent=false)=>{stop();setBusy(false);setProgress(null);setStatus(silent?'':'Translation cancelled.');};
  useEffect(()=>{setSource(detectedSource);},[options.email,detectedSource]);
  useEffect(()=>{
    stop();setBusy(false);setStatus('');setProgress(null);
    let active=true;
    if(!api){setState({key:pairKey,value:'unsupported'});return;}
    if(!source || !options.target || source===options.target){setState({key:pairKey,value:'choose'});return;}
    setState({key:pairKey,value:'checking'});
    const check=new AbortController();
    const timeout=setTimeout(()=>check.abort(),8000);
    abortable(Promise.resolve().then(()=>api.availability({sourceLanguage:source,targetLanguage:options.target})),check.signal).then(value=>{
      if(active)setState({key:pairKey,value:['available','downloadable','downloading'].includes(value)?value:'unavailable'});
    }).catch(()=>{if(active)setState({key:pairKey,value:'error'});}).finally(()=>clearTimeout(timeout));
    return()=>{active=false;clearTimeout(timeout);check.abort();stop();};
  },[options.email,source,options.target,checkVersion]);
  useEffect(()=>()=>stop(),[]);
  const availability=state.key===pairKey?state.value:'checking';
  const canTranslate=!!api && !busy && ['available','downloadable','downloading'].includes(availability);
  const untouched=options.email.fields.filter(f=>options.changes[f.id]===undefined || options.changes[f.id]===f.original).length;
  const run=async(id?:string)=>{
    if(!canTranslate || !api || job.current)return;
    const initial=latest.current;
    const fields=initial.email.fields.filter(f=>id?f.id===id:initial.changes[f.id]===undefined || initial.changes[f.id]===f.original);
    if(!fields.length){setStatus('Nothing to translate.');return;}
    const current={controller:new AbortController(),session:undefined as LocalTranslator|undefined};
    job.current=current;const signal=current.controller.signal;
    setBusy(true);setProgress(null);setStatus(availability==='available'?'Translating…':'Preparing language pack…');
    let completed=0,skipped=0;
    try {
      current.session=await openTranslator(api,{sourceLanguage:source,targetLanguage:initial.target},signal,value=>{
        if(job.current===current){setProgress(value);setStatus(`Downloading: ${Math.round(value*100)}%`);}
      });
      setProgress(null);
      for(let i=0;i<fields.length;i++) {
        const field=fields[i];
        if(signal.aborted || latest.current.email!==initial.email || latest.current.target!==initial.target)return;
        if(latest.current.changes[field.id]!==initial.changes[field.id]){skipped++;continue;}
        setStatus(`Translating ${i+1} of ${fields.length}…`);
        const value=await translateField(current.session,initial.email,field,signal);
        if(signal.aborted || latest.current.email!==initial.email || latest.current.target!==initial.target)return;
        if(latest.current.changes[field.id]!==initial.changes[field.id]){skipped++;continue;}
        latest.current.apply(field.id,value,initial.changes[field.id]);completed++;
      }
      setStatus(skipped ? `${skipped} manually edited block${skipped===1?' was':'s were'} kept.` : '');
      setState({key:pairKey,value:'available'});
    }catch(error){
      if(!signal.aborted && job.current===current){
        const reason=error instanceof Error?error.message:'Translation failed.';
        setStatus(`Translation stopped (${completed} completed). ${reason}`);
      }
    }finally{
      destroy(current.session);
      if(job.current===current){job.current=undefined;setBusy(false);setProgress(null);}
    }
  };
  return {supported:!!api,source,setSource,detectedSource,availability,canTranslate,busy,status,progress,untouched,run,cancel,retry:()=>setCheckVersion(version=>version+1)};
}
export type OnDeviceTranslation=ReturnType<typeof useOnDeviceTranslation>;
