import {describe,it,expect,vi} from 'vitest';
import {readEmail,exportEmail} from './email';
import {nativeTranslator,detectSourceLanguage,openTranslator,translateField,abortable,type LocalTranslator,type TranslatorFactory} from './on-device';
const html=(content:string)=>`<html lang="en"><body>${content}</body></html>`;
describe('on-device translation adapter',()=>{
  it('detects substantial email text and falls back to the declared language for short text',()=>{
    const french=readEmail(html('<p>Bonjour et bienvenue dans notre boutique. Découvrez nos nouveaux produits et profitez de nos offres exceptionnelles dès aujourd’hui.</p>'));
    expect(detectSourceLanguage(french)).toBe('fr');
    expect(detectSourceLanguage(readEmail(html('<p>Bonjour</p>')))).toBe('en');
    expect(detectSourceLanguage(readEmail('<html><body><p>Hello</p></body></html>'))).toBe('');
  });
  it('does not offer a cloud or deprecated API fallback',()=>{
    vi.stubGlobal('Translator',undefined);
    expect(nativeTranslator()).toBeUndefined();
    vi.stubGlobal('ai',{translator:{}});
    expect(nativeTranslator()).toBeUndefined();
    vi.unstubAllGlobals();
  });
  it('creates the translator immediately in the caller gesture and reports download progress',async()=>{
    let created=false;const values:number[]=[];
    const session:LocalTranslator={translate:async t=>t,destroy:vi.fn()};
    const factory:TranslatorFactory={availability:async()=> 'downloadable',create:options=>{
      created=true;
      expect(options.sourceLanguage).toBe('en');expect(options.targetLanguage).toBe('fr');
      options.monitor?.({addEventListener:(_name,callback)=>{callback({loaded:0.5});callback({loaded:2});}});
      return Promise.resolve(session);
    }};
    const result=openTranslator(factory,{sourceLanguage:'en',targetLanguage:'fr'},new AbortController().signal,v=>values.push(v));
    expect(created).toBe(true);expect(await result).toBe(session);expect(values).toEqual([0.5,1]);
  });
  it('keeps HTML, expressions and destination URLs out of model input',async()=>{
    const source=html('<p>Hello {{Name}} welcome</p><a href="https://example.com/private">Continue</a>');
    const email=readEmail(source);const inputs:string[]=[];
    const translator:LocalTranslator={translate:async text=>{inputs.push(text);return 'Bonjour';},destroy:vi.fn()};
    const changes:Record<string,string>={};
    for(const f of email.fields)changes[f.id]=await translateField(translator,email,f,new AbortController().signal);
    expect(inputs).toEqual(['Hello','welcome','Continue']);
    expect(exportEmail(email,changes)).toContain('Bonjour {{Name}} Bonjour');
    expect(exportEmail(email,changes)).toContain('href="https://example.com/private"');
  });
  it('translates each text section sequentially and retains its original markup',async()=>{
    const source=html('<div data-editorblocktype="Text"><p>First</p><p>Second</p></div>');
    const email=readEmail(source);const inputs:string[]=[];
    const session:LocalTranslator={translate:async text=>{inputs.push(text);return text==='First'?'Premier':'Deuxième';},destroy:vi.fn()};
    const translated=await translateField(session,email,email.fields[0],new AbortController().signal);
    expect(inputs).toEqual(['First','Second']);expect(translated).toBe('Premier\nDeuxième');
    expect(exportEmail(email,{[email.fields[0].id]:translated})).toBe(source.replace('First','Premier').replace('Second','Deuxième'));
  });
  it('updates linked Outlook text using the same translated result',async()=>{
    const source=html('<!--[if mso]><v:roundrect data-msdyn-tracking-id="cta"><center>Buy</center></v:roundrect><![endif]--><a href="#" data-msdyn-tracking-id="cta">Buy</a>');
    const email=readEmail(source);const translate=vi.fn(async()=> 'Acheter');
    const value=await translateField({translate,destroy:vi.fn()},email,email.fields[0],new AbortController().signal);
    expect(translate).toHaveBeenCalledTimes(1);expect(exportEmail(email,{[email.fields[0].id]:value})).toBe(source.replaceAll('Buy','Acheter'));
  });
  it('rejects empty, injected-token and malformed model outputs before applying them',async()=>{
    const email=readEmail(html('<p>Hello</p>'));
    for(const output of ['','{{Injected}}','\u200b']) {
      await expect(translateField({translate:async()=>output,destroy:vi.fn()},email,email.fields[0],new AbortController().signal)).rejects.toThrow();
    }
  });
  it('cancels an unresolved model creation and destroys any late session',async()=>{
    const controller=new AbortController();let finish!:(s:LocalTranslator)=>void;
    const session:LocalTranslator={translate:async t=>t,destroy:vi.fn()};
    const api:TranslatorFactory={availability:async()=> 'available',create:()=>new Promise(resolve=>{finish=resolve;})};
    const opened=openTranslator(api,{sourceLanguage:'en',targetLanguage:'fr'},controller.signal,()=>{});
    controller.abort();await expect(opened).rejects.toMatchObject({name:'AbortError'});
    finish(session);await Promise.resolve();expect(session.destroy).toHaveBeenCalled();
  });
  it('cancels a pending translation even if a browser does not honor its signal',async()=>{
    const controller=new AbortController();const pending=abortable(new Promise<string>(()=>{}),controller.signal);
    controller.abort();await expect(pending).rejects.toMatchObject({name:'AbortError'});
  });
});
