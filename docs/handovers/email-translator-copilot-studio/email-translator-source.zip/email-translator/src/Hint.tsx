import { useId, useState, type ReactElement } from 'react';

export function Hint({text, children}: {text: string; children: (id: string) => ReactElement}) {
  const id = useId();
  const [dismissed, setDismissed] = useState(false);
  return <span className="hint-wrap" data-dismissed={dismissed} onPointerEnter={() => setDismissed(false)} onFocusCapture={() => setDismissed(false)} onKeyDown={e => {if(e.key === 'Escape')setDismissed(true);}}>{children(id)}<span className="control-hint" id={id} role="tooltip">{text}</span></span>;
}
