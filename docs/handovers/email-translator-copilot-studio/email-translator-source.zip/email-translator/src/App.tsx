import { useEffect, useReducer, useState } from 'react';
import { Upload } from 'lucide-react';
import { readEmail, exportEmail, type Email } from './email';
import { EmailPreview } from './EmailPreview';
import { TranslationPanel } from './TranslationPanel';
import { sample } from './sample';
import { PasteHtmlDialog } from './PasteHtmlDialog';
import { HtmlExportDialog } from './HtmlExportDialog';
import { useOnDeviceTranslation } from './useOnDeviceTranslation';
import { draftReducer, emptyDrafts, hasDraftChanges } from './translation-drafts';
export default function App() {
  const [email,setEmail]=useState<Email>(()=>readEmail(sample));
  const [draftState,dispatchDraft]=useReducer(draftReducer,emptyDrafts);
  const {changes,language}=draftState;
  const [mobileView,setMobileView]=useState<'preview'|'translations'>('translations');
  const [errors,setErrors]=useState<Record<string,string>>({});
  const [message,setMessage]=useState('');
  const [error,setError]=useState('');
  const [exportSource,setExportSource]=useState<string|null>(null);
  const [documentId,setDocumentId]=useState(0);
  const [selection,setSelection]=useState<{id:string;seq:number}|null>(null);
  const hasChanges=hasDraftChanges(draftState,email.fields);
  const dirty=hasChanges||!!language;
  useEffect(()=>{
    const prevent=(e:BeforeUnloadEvent)=>{if(dirty){e.preventDefault();}};
    window.addEventListener('beforeunload',prevent);return()=>window.removeEventListener('beforeunload',prevent);
  },[dirty]);
  const reset=()=>{translation.cancel(true);dispatchDraft({type:'reset'});setErrors({});setError('');setMessage('Reset to original.');};
  const replace=(next:Email,filename:string)=>{
    setDocumentId(id=>id+1);setSelection(null);setEmail(next);dispatchDraft({type:'reset'});setErrors({});setError('');setMessage(`${filename} loaded (${next.fields.length} fields).`);
  };
  const loadPasted=(next:Email)=>{
    replace(next,'pasted-email.html');return true;
  };
  const change=(id:string,value:string)=>{dispatchDraft({type:'change',id,value});setErrors(prev=>{const next={...prev};delete next[id];return next;});setError('');setMessage('');};
  const validate=(id:string)=>{
    if(changes[id]===undefined)return true;
    try{exportEmail(email,{[id]:changes[id]});return true;}
    catch(e){setErrors(prev=>({...prev,[id]:e instanceof Error?e.message:'Enter wording only.'}));return false;}
  };
  const translation=useOnDeviceTranslation({email,changes,target:language,apply:(id,value,expected)=>{
    dispatchDraft({type:'apply',id,value,expected});
    setErrors(previous=>{const next={...previous};delete next[id];return next;});
    setError('');setMessage('');
  }});
  const selectLanguage=(next:string)=>{translation.cancel(true);dispatchDraft({type:'select',language:next});setErrors({});setError('');setMessage('');setSelection(null);};
  let edited=email.source;
  try{edited=exportEmail(email,changes,language);}catch{/* Invalid values stay out of the display copy. */}
  const openExport=()=>{
    const invalid=email.fields.find(f=>!validate(f.id));
    if(invalid){setError('Fix highlighted errors before exporting.');document.getElementById(invalid.id)?.focus();return;}
    let output:string;
    try{output=exportEmail(email,changes,language);}
    catch(e){setError(e instanceof Error?e.message:'Export failed.');return;}
    setError('');setMessage('');setExportSource(output);
  };
  return <>
    <main>
      <h1 className="visually-hidden">Email Studio</h1>
      {error&&<div className="error-banner" role="alert">{error}</div>}
      <div className="mobile-view-switch segmented" role="group" aria-label="Workspace view">{(['preview','translations'] as const).map(view=><button key={view} type="button" aria-pressed={mobileView===view} className={mobileView===view?'active':''} onClick={()=>setMobileView(view)}>{view==='preview'?'Preview':'Translations'}</button>)}</div>
      <div className="workspace" data-mobile-view={mobileView}><EmailPreview key={documentId} source={edited} original={email.source} email={email} changes={changes} selection={selection} actions={<><PasteHtmlDialog dirty={dirty} onLoad={loadPasted}/><button className="button primary" type="button" onClick={openExport}><Upload size={17} aria-hidden="true"/>Export</button></>}/><TranslationPanel email={email} changes={changes} setChange={change} language={language} setLanguage={selectLanguage} hasChanges={hasChanges} onReset={reset} errors={errors} onValidate={validate} translation={translation} activeFieldId={selection?.id??null} onSelectField={id=>setSelection(prev=>({id,seq:(prev?.seq??0)+1}))}/></div>
      <p className="status" role="status" aria-live="polite">{message}</p>
      <HtmlExportDialog source={exportSource} onClose={()=>setExportSource(null)}/>
    </main></>;
}
