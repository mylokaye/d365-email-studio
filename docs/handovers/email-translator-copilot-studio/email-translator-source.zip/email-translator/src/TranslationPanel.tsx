import { useState } from 'react';
import { RotateCcw, Link2, LoaderCircle } from 'lucide-react';
import type { Email } from './email';
import { languages } from './languages';
import { OnDeviceControls } from './OnDeviceControls';
import { ConfirmDialog } from './Dialog';
import { Hint } from './Hint';
import type { OnDeviceTranslation } from './useOnDeviceTranslation';

const featuredCodes = ['de', 'fr', 'es', 'pl', 'it', 'zh'] as const;
type Props = {
  email: Email; changes: Record<string, string>; setChange: (id: string, value: string) => void;
  language: string; setLanguage: (value: string) => void; hasChanges: boolean; onReset: () => void;
  errors: Record<string, string>; onValidate: (id: string) => void; translation: OnDeviceTranslation;
  activeFieldId?: string | null; onSelectField?: (id: string) => void;
};

function unavailableReason(t: OnDeviceTranslation, language: string) {
  if (!t.supported) return 'Automatic translation is unavailable in this browser. You can edit the wording manually.';
  if (!t.source) return 'Choose the source language first.';
  if (!language) return 'Choose a language to translate into.';
  if (t.busy) return 'A translation is already in progress.';
  if (t.availability === 'checking') return 'Checking whether this language is available.';
  if (t.availability === 'error') return 'Language check failed. Use Retry to check this language again.';
  if (!t.canTranslate) return 'This language pair is unavailable. Choose another language.';
  return '';
}

export function TranslationPanel({email, changes, setChange, language, setLanguage, hasChanges, onReset, errors, onValidate, translation, activeFieldId, onSelectField}: Props) {
  const [confirmReset, setConfirmReset] = useState(false);
  const featured = featuredCodes.flatMap(code => languages.filter(([id]) => id === code && id !== translation.source));
  const others = languages.filter(([code]) => code !== translation.source && !featuredCodes.some(featuredCode => featuredCode === code));
  const reason = unavailableReason(translation, language);
  const allReason = reason || (!translation.untouched ? 'All blocks have been edited. Use Re-translate on an individual block.' : '');
  return <section className="panel translation-panel" aria-label="Translations">
    <div className="panel-heading"><h2>Translations</h2></div>
    <fieldset className={'language-pair' + (translation.detectedSource ? ' source-detected' : '')}>
      <legend className="visually-hidden">Translation languages</legend>
      {!translation.detectedSource && <label htmlFor="source-language">Source<select id="source-language" name="source-language" value={translation.source} onChange={e => {const source=e.target.value; translation.setSource(source); if(source===language)setLanguage('');}}>
        <option value="">Select…</option>
        {translation.source && !languages.some(([code]) => code === translation.source) && <option value={translation.source}>{translation.source}</option>}
        {languages.map(([code, name]) => <option key={code} value={code}>{name}</option>)}
      </select></label>}
      <label htmlFor="language"><span className="visually-hidden">Target language</span><select id="language" name="language" value={language} onChange={e => setLanguage(e.target.value)} aria-describedby="language-drafts-help">
        <option value="" hidden disabled>Select language</option>
        {featured.map(([code, title]) => <option key={code} value={code}>{title}</option>)}
        <optgroup label="More">{others.map(([code, title]) => <option key={code} value={code}>{title}</option>)}</optgroup>
      </select><span className="visually-hidden" id="language-drafts-help">Each target language keeps its own draft while this email is open.</span></label>
      <div className="translation-action">
        {translation.busy ? <button type="button" className="button primary translate-button" onClick={() => translation.cancel()}><LoaderCircle className="busy-icon" size={16} aria-hidden="true"/>Cancel<span className="visually-hidden"> translation</span></button> : <Hint text={allReason || 'Translate all untouched blocks'}>{id => <button type="button" className="button primary translate-button" aria-disabled={!!allReason} aria-describedby={id} onClick={() => {if(!allReason)void translation.run();}}>Translate</button>}</Hint>}
        <Hint text="Reset all translations and language drafts">{id => <button type="button" className="button secondary icon-button reset-all" aria-label="Reset all" aria-describedby={id} disabled={!hasChanges && !language} onClick={() => setConfirmReset(true)}><RotateCcw size={17} aria-hidden="true"/></button>}</Hint>
      </div>
    </fieldset>
    <ConfirmDialog open={confirmReset} title="Reset all translations?" description="This will discard all translations and language drafts, and reset the target language." confirmLabel="Reset all" onCancel={() => setConfirmReset(false)} onConfirm={() => {setConfirmReset(false); onReset();}}/>
    <OnDeviceControls translation={translation}/>
    <div className="translation-list" aria-busy={translation.busy}>
      {email.notices.length > 0 && <div className="notices">{email.notices.map(note => <p key={note}>{note}</p>)}</div>}
      {email.fields.map((field, i) => {
        const value = changes[field.id];
        const edited = value !== undefined && value !== field.original;
        const active = activeFieldId === field.id;
        const hasTranslation = edited && value.trim().length > 0;
        return <article key={field.id} className={'translation-card' + (hasTranslation ? ' changed' : '') + (active ? ' active-card' : '')} onClick={() => onSelectField?.(field.id)} onFocusCapture={() => {if(!active)onSelectField?.(field.id);}}>
          <div className="card-top"><span className="number">{i+1}</span><span className="field-label">{field.label}</span>
            {field.paired && <span className="paired"><Link2 size={13} aria-hidden="true"/>Outlook linked</span>}
            {hasTranslation && <span className="visually-hidden">Edited</span>}
            <div className="field-actions">
              <Hint text={reason || `Translate block ${i+1}`}>{id => <button type="button" className="button secondary compact" aria-disabled={!!reason} aria-describedby={id} onClick={() => {if(!reason)void translation.run(field.id);}}>{edited ? 'Re-translate' : 'Translate'}<span className="visually-hidden"> block {i+1}</span></button>}</Hint>
              {edited && <Hint text={`Restore original wording for block ${i+1}`}>{id => <button type="button" className="button secondary compact icon-button reset-field" aria-label={`Reset block ${i+1}`} aria-describedby={id} onClick={() => setChange(field.id, field.original)}><RotateCcw size={16} aria-hidden="true"/></button>}</Hint>}
            </div>
          </div>
          <label className="visually-hidden" htmlFor={field.id}>Translation block {i+1}</label>
          {field.sections && <p className="section-help" id={`${field.id}-help`}>{field.sections.length} lines — keep one section per line.</p>}
          <textarea id={field.id} name={field.id} lang={(edited ? language : translation.source || email.language?.value) || undefined} value={value ?? field.original} onChange={e => setChange(field.id, e.target.value)} onBlur={() => onValidate(field.id)} rows={field.sections ? Math.min(12, Math.max(4, field.sections.length*2)) : field.original.length>100 ? 4 : 2} placeholder="Enter translation…" spellCheck aria-invalid={!!errors[field.id]} aria-describedby={[field.sections ? `${field.id}-help` : '', errors[field.id] ? `${field.id}-error` : ''].filter(Boolean).join(' ') || undefined}/>
          {errors[field.id] && <p className="field-error" id={`${field.id}-error`}>{errors[field.id]}</p>}
        </article>;
      })}
    </div>
  </section>;
}
