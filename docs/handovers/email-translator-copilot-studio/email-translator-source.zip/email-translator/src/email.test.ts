import { describe,it,expect } from 'vitest';
import { readFileSync } from 'node:fs';
import { readEmail, exportEmail } from './email';
const page=(s:string)=>`<!doctype html><html lang="en"><head><title>Protected subject</title><style>p{color:red}</style></head><body>${s}</body></html>`;
describe('source-preserving text editing',()=>{
  it('exports unchanged UTF-8 BOM and CRLF source exactly',()=>{
    const source='\ufeff'+page('<p>Hello</p>\r\n<p>World</p>');
    expect(exportEmail(readEmail(source),{})).toBe(source);
    expect(exportEmail(readEmail(source),{},'fr')).toBe(source.replace('lang="en"','lang="fr"'));
  });
  it('escapes entered markup and changes only the selected repeated occurrence',()=>{
    const source=page('<p>Hello</p><p>Hello</p><a href="https://example.com#_msdynmkt_linkid=1">Link</a>');
    const email=readEmail(source);
    expect(exportEmail(email,{[email.fields[0].id]:'<b>Bonjour & salut</b>'})).toBe(source.replace('<p>Hello</p>','<p>&lt;b&gt;Bonjour &amp; salut&lt;/b&gt;</p>'));
  });
  it('protects tokens and encoded padding while translating surrounding words',()=>{
    const source=page('<p>Hello {{Name}} welcome&#8203;friend</p>');
    const email=readEmail(source);
    expect(email.fields.map(f=>f.original)).toEqual(['Hello','welcome','friend']);
    const translated=exportEmail(email,Object.fromEntries(email.fields.map(f=>[f.id,'Bonjour'])));
    expect(translated).toContain('Bonjour {{Name}} Bonjour&#8203;Bonjour');
  });
  it('does not offer head, script, style, comments or template content',()=>{
    const email=readEmail(page('<script>bad()</script><template><p>Hidden</p></template><!-- Secret --><p>Visible</p>'));
    expect(email.fields.map(f=>f.original)).toEqual(['Visible']);
  });
  it('updates corresponding Outlook and normal button labels together',()=>{
    const source=page('<!--[if mso]><v:roundrect href="https://example.com" data-msdyn-tracking-id="x"><center>Buy now</center></v:roundrect><![endif]--><a href="https://example.com" data-msdyn-tracking-id="x">Buy now</a>');
    const email=readEmail(source);
    expect(email.fields).toHaveLength(1);
    expect(email.fields[0].paired).toBe(true);
    expect(exportEmail(email,{[email.fields[0].id]:'Acheter'})).toBe(source.replaceAll('Buy now','Acheter'));
  });
  it('leaves unpaired Outlook wording read-only',()=>{
    const email=readEmail(page('<!--[if mso]><v:roundrect><center>Buy now</center></v:roundrect><![endif]--><a href="#">Buy now</a><p>Hello</p>'));
    expect(email.fields.some(f=>f.original==='Buy now')).toBe(false);
    expect(email.notices.length).toBeGreaterThan(0);
  });
  it('leaves inconsistent and reused tracking counterparts read-only',()=>{
    const email=readEmail(page('<!--[if mso]><v:roundrect data-msdyn-tracking-id="x"><center>Buy</center></v:roundrect><![endif]--><a href="#" data-msdyn-tracking-id="x">Read</a>'));
    expect(email.fields).toHaveLength(0);
  });
  it('rejects erased or newly injected tokens',()=>{
    const email=readEmail(page('<p>Hello</p>'));
    for(const replacement of ['', '  ', '{{Injected}}','\u200b']) expect(()=>exportEmail(email,{[email.fields[0].id]:replacement})).toThrow();
  });
  it('changes only an existing root language attribute',()=>{
    const source=page('<p>Hello</p>');
    expect(exportEmail(readEmail(source),{},'fr')).toBe(source.replace('lang="en"','lang="fr"'));
    const missing=source.replace(' lang="en"','');
    expect(exportEmail(readEmail(missing),{},'fr')).toBe(missing);
  });
  it('retains inline segmentation, empty tags, tracking and image metadata',()=>{
    const source=page('<p>Hello <strong>world</strong>!</p><img alt="Logo" src="https://example.com/a" data-image-file-id="asset"><a href="{{PreferenceCenter}}">Unsubscribe</a>');
    const email=readEmail(source);
    const f=email.fields.find(f=>f.original==='Hello\nworld\n!')!;
    expect(exportEmail(email,{[f.id]:'Hello\nmonde\n!'})).toBe(source.replace('<strong>world</strong>','<strong>monde</strong>'));
  });
  it('groups the screenshot example into its containing Dynamics Text block',()=>{
    const source=readFileSync(new URL('../tests/fixtures/example2.html',import.meta.url),'utf8');
    const email=readEmail(source);
    const block=email.fields.find(f=>f.original.startsWith('The F Word Collection.'))!;
    expect(block.original).toBe("The F Word Collection.\nFor athletes who don't\nwaste time on trivialities.");
    expect(block.sections).toHaveLength(3);
    expect(email.fields.some(f=>f.original==="For athletes who don't")).toBe(false);
    expect(email.fields.some(f=>f.original==='SHOP NEW STYLES')).toBe(true);
    const translated='La collection F Word.\nPour les athlètes qui ne\nperdent pas leur temps en futilités.';
    let expected=source;
    block.sections!.forEach((s,i)=>s.ranges.forEach(r=>{expected=expected.replace(r.raw,translated.split('\n')[i]);}));
    expect(exportEmail(email,{[block.id]:translated})).toBe(expected);
  });
  it('groups line breaks and inline spans without combining unrelated paragraphs',()=>{
    const source=page('<p><span>First line</span><br><span>Second line</span></p><p>Separate paragraph</p>');
    const email=readEmail(source);
    expect(email.fields.map(f=>f.original)).toEqual(['First line\nSecond line','Separate paragraph']);
    expect(exportEmail(email,{[email.fields[0].id]:'Première ligne\nDeuxième ligne'})).toBe(source.replace('First line','Première ligne').replace('Second line','Deuxième ligne'));
    expect(()=>exportEmail(email,{[email.fields[0].id]:'One merged line'})).toThrow('separate lines');
    expect(()=>exportEmail(email,{[email.fields[0].id]:'First\n'})).toThrow('Each text section');
  });
  it('leaves untouched sections and their original entities byte-for-byte intact',()=>{
    const source=page('<div data-editorblocktype="Text"><p>A &amp; B</p><p>Change this</p></div>');
    const email=readEmail(source);
    expect(exportEmail(email,{[email.fields[0].id]:'A & B\nTexte traduit'})).toBe(source.replace('Change this','Texte traduit'));
  });
  it('reads all shipped source fixtures without changing any bytes',()=>{
    for(const name of ['example1.html','example2.html','example3.html','exported-original.html']) {
      const source=readFileSync(new URL('../tests/fixtures/'+name,import.meta.url),'utf8');
      const email=readEmail(source);
      expect(exportEmail(email,{})).toBe(source);
      expect(email.fields.length).toBeGreaterThan(0);
    }
  });
  it('updates paired labels in a real exported Dynamics email',()=>{
    const source=readFileSync(new URL('../tests/fixtures/exported-original.html',import.meta.url),'utf8');
    const email=readEmail(source);
    const button=email.fields.find(f=>f.original==='Button');
    expect(button?.paired).toBe(true);
    expect(exportEmail(email,{[button!.id]:'Continuer'})).toBe(source.replaceAll('>Button<','>Continuer<'));
  });
});
