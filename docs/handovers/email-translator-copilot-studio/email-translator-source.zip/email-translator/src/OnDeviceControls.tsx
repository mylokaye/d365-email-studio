import type {OnDeviceTranslation} from './useOnDeviceTranslation';
export function OnDeviceControls({translation:t}:{translation:OnDeviceTranslation}) {
  const message=t.busy?'':t.status || (!t.supported?'On-device translation is unavailable in this browser.':t.availability==='error'?'Language check failed. Try again.':t.availability==='unavailable'?'This language pair is unavailable.':'');
  return <>
    {t.progress!==null&&<progress className="translation-progress" max={1} value={t.progress} aria-label="Language pack download progress"/>}
    <div className="translation-feedback"><p className="translation-status" role="status" aria-live="polite">{message}</p>{t.availability==='error'&&<button type="button" className="button secondary compact" onClick={t.retry}>Retry<span className="visually-hidden"> language check</span></button>}</div>
  </>;
}
