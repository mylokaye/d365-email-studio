import { exportEmail, type Email, type Field } from './email';
import { francAll } from 'franc-min';
import { iso6393 } from 'iso-639-3';
import { languages } from './languages';
export type Availability='unavailable'|'downloadable'|'downloading'|'available';
export type LanguagePair={sourceLanguage:string;targetLanguage:string};
export type LocalTranslator={translate:(text:string,options?:{signal?:AbortSignal})=>Promise<string>;destroy:()=>void};
export type TranslatorFactory={
  availability:(pair:LanguagePair)=>Promise<Availability>;
  create:(options:LanguagePair & {signal?:AbortSignal;monitor?:(monitor:{addEventListener:(name:'downloadprogress',callback:(event:{loaded:number})=>void)=>void})=>void})=>Promise<LocalTranslator>;
};
export function nativeTranslator():TranslatorFactory|undefined {
  const api=(globalThis as unknown as {Translator?:TranslatorFactory}).Translator;
  return typeof api?.availability==='function' && typeof api?.create==='function'?api:undefined;
}
export function sourceLanguage(email:Email) {
  try{return email.language?.value?new Intl.Locale(email.language.value).language:'';}catch{return '';}
}
export function detectSourceLanguage(email: Email): string {
  const text = email.fields.filter(field => field.kind === 'text').map(field => field.original).join(' ').slice(0, 10000);
  const fallback = sourceLanguage(email);
  if ((text.match(/\p{L}/gu)?.length ?? 0) < 80) return fallback;
  const results = francAll(text);
  if (!results.length || results[0][0] === 'und' || (results[1] && results[0][1] - results[1][1] < 0.1)) return fallback;
  const code = iso6393.find(language => language.iso6393 === results[0][0])?.iso6391;
  return code && languages.some(([supported]) => supported === code) ? code : fallback;
}
function abortError(){return new DOMException('Translation cancelled.','AbortError');}
export function abortable<T>(promise:Promise<T>,signal:AbortSignal):Promise<T> {
  return new Promise((resolve,reject)=>{
    const cancel=()=>reject(abortError());
    if(signal.aborted){promise.catch(()=>{});cancel();return;}
    signal.addEventListener('abort',cancel,{once:true});
    promise.then(value=>{signal.removeEventListener('abort',cancel);signal.aborted?cancel():resolve(value);},error=>{signal.removeEventListener('abort',cancel);reject(error);});
  });
}
export function destroy(translator?:LocalTranslator){try{translator?.destroy();}catch{/* Already closed. */}}
export function openTranslator(api:TranslatorFactory,pair:LanguagePair,signal:AbortSignal,onProgress:(value:number)=>void) {
  if(signal.aborted)return Promise.reject(abortError());
  // Called directly from the click handler, before any await, to retain activation.
  const creating=api.create({...pair,signal,monitor(monitor){monitor.addEventListener('downloadprogress',event=>{
    if(!signal.aborted && Number.isFinite(event.loaded))onProgress(Math.max(0,Math.min(1,event.loaded)));
  });}});
  void creating.then(session=>{if(signal.aborted)destroy(session);},()=>{});
  return abortable(creating,signal);
}
export async function translateField(session:LocalTranslator,email:Email,field:Field,signal:AbortSignal) {
  const sections=field.sections??[{original:field.original}];
  const result:string[]=[];
  for(const section of sections) {
    if(signal.aborted)throw abortError();
    // Translate only editable wording, not source markup, destinations or protected expressions.
    const translated=await abortable(session.translate(section.original,{signal}),signal);
    if(typeof translated!=='string')throw new Error('Chrome returned an invalid translation.');
    result.push(translated.trim().replace(/\s*\r?\n\s*/g,' '));
  }
  const value=result.join(field.sections?'\n':'');
  exportEmail(email,{[field.id]:value});
  return value;
}
