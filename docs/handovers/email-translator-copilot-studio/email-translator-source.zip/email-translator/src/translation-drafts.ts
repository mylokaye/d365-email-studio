export type Changes = Record<string, string>;
export type DraftState = {language: string; changes: Changes; drafts: Record<string, Changes>};
export const emptyDrafts: DraftState = {language: '', changes: {}, drafts: {}};
type Action = {type: 'select'; language: string} | {type: 'change'; id: string; value: string} | {type: 'apply'; id: string; value: string; expected: string | undefined} | {type: 'reset'};

export function draftReducer(state: DraftState, action: Action): DraftState {
  if (action.type === 'reset') return emptyDrafts;
  if (action.type === 'select') {
    if (state.language === action.language) return state;
    const drafts = {...state.drafts};
    if (state.language) drafts[state.language] = state.changes;
    // Edits entered before choosing a target belong to the first selected language.
    const changes = drafts[action.language] ?? (state.language ? {} : state.changes);
    return {language: action.language, changes, drafts};
  }
  if (action.type === 'apply' && state.changes[action.id] !== action.expected) return state;
  return {...state, changes: {...state.changes, [action.id]: action.value}};
}

export function hasDraftChanges(state: DraftState, fields: {id: string; original: string}[]) {
  const changed = (changes: Changes) => fields.some(field => changes[field.id] !== undefined && changes[field.id] !== field.original);
  return changed(state.changes) || Object.entries(state.drafts).some(([language, changes]) => language !== state.language && changed(changes));
}
