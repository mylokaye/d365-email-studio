import defaultEmail from './default-email.html?raw';

export const sample = defaultEmail;
