import { useEffect, useRef, useState } from 'react';
import { Dialog, openDialog } from './Dialog';

export function HtmlExportDialog({source,onClose}:{source:string|null;onClose:()=>void}) {
  const dialog=useRef<HTMLDialogElement>(null);
  const field=useRef<HTMLTextAreaElement>(null);
  const [status,setStatus]=useState('');
  useEffect(()=>{
    if(source!==null){
      setStatus('');
      openDialog(dialog);
      field.current?.select();
    } else if(dialog.current?.open)dialog.current.close();
  },[source]);
  const copy=async()=>{
    if(source===null)return;
    try{await navigator.clipboard.writeText(source);setStatus('HTML copied.');}
    catch{field.current?.focus();field.current?.select();setStatus('Copy failed. Select the HTML and copy it manually.');}
  };
  return <Dialog dialogRef={dialog} title="Export HTML" onClose={onClose}>
    <label className="visually-hidden" htmlFor="copy-source">Exported HTML</label>
    <textarea ref={field} data-dialog-autofocus autoFocus id="copy-source" name="copy-source" value={source??''} readOnly spellCheck={false}/>
    <p className="export-status" role="status" aria-live="polite">{status}</p>
    <div className="paste-actions"><button className="button primary" type="button" onClick={()=>void copy()}>Copy</button></div>
  </Dialog>;
}
