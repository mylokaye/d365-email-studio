import { useEffect, useId, useRef, type ReactNode, type RefObject } from 'react';
import { X } from 'lucide-react';
import { Hint } from './Hint';

export function openDialog(ref: RefObject<HTMLDialogElement | null>) {
  const dialog = ref.current;
  if (!dialog || dialog.open) return;
  dialog.returnValue = '';
  dialog.showModal();
  dialog.querySelector<HTMLElement>('[data-dialog-autofocus]')?.focus();
}

function useLightDismiss(ref: RefObject<HTMLDialogElement | null>) {
  useEffect(() => {
    const dialog = ref.current;
    if (!dialog || 'closedBy' in HTMLDialogElement.prototype) return;
    const outside = (e: PointerEvent) => {
      const r = dialog.getBoundingClientRect();
      return e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom;
    };
    let pressedOutside = false;
    const down = (e: PointerEvent) => { pressedOutside = outside(e); };
    const up = (e: PointerEvent) => { if (pressedOutside && outside(e)) dialog.close(); pressedOutside = false; };
    dialog.addEventListener('pointerdown', down);
    dialog.addEventListener('pointerup', up);
    return () => { dialog.removeEventListener('pointerdown', down); dialog.removeEventListener('pointerup', up); };
  }, [ref]);
}

export function Dialog({dialogRef, title, description, compact = false, onClose, children}: {
  dialogRef: RefObject<HTMLDialogElement | null>;
  title: string;
  description?: string;
  compact?: boolean;
  onClose?: () => void;
  children: ReactNode;
}) {
  const id = useId();
  useLightDismiss(dialogRef);
  return <dialog ref={dialogRef} className={'paste-dialog' + (compact ? ' confirm-dialog' : '')} {...({closedby: 'any'} as any)} aria-labelledby={id} aria-describedby={description ? `${id}-help` : undefined} onClose={onClose}>
    <div className="paste-heading"><h2 id={id}>{title}</h2><Hint text="Close dialog">{hintId => <button type="button" className="button secondary icon-button dialog-close" aria-label={`Close ${title.replace(/\?$/, '').toLowerCase()} dialog`} aria-describedby={hintId} onClick={() => dialogRef.current?.close()}><X size={20} aria-hidden="true"/></button>}</Hint></div>
    {description && <p id={`${id}-help`}>{description}</p>}
    {children}
  </dialog>;
}

export function ConfirmDialog({open, title, description, confirmLabel, onConfirm, onCancel}: {
  open: boolean; title: string; description: string; confirmLabel: string; onConfirm: () => void; onCancel: () => void;
}) {
  const dialog = useRef<HTMLDialogElement>(null);
  useEffect(() => { if (open) openDialog(dialog); else dialog.current?.close(); }, [open]);
  return <Dialog dialogRef={dialog} title={title} description={description} compact onClose={() => {
    const choice = dialog.current?.returnValue;
    if (dialog.current) dialog.current.returnValue = '';
    if (choice === 'confirm') onConfirm(); else onCancel();
  }}>
    <form method="dialog" className="paste-actions">
      <button className="button secondary" type="submit" value="cancel" data-dialog-autofocus autoFocus>Cancel</button>
      <button className="button primary" type="submit" value="confirm">{confirmLabel}</button>
    </form>
  </Dialog>;
}
