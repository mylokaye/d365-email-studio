const blockedTags=['script','iframe','object','embed','form','input','button','select','textarea','link','meta','base','svg','math','video','audio','source'];
const blockedAttrs=['href','xlink:href','srcset','action','formaction','ping','poster','background','autofocus','contenteditable','is','attributionsrc'];
type NativeParser = {parseHTML?:(html:string,options:{sanitizer:{removeElements:string[];removeAttributes:string[]}})=>Document};

// Preview HTML is a disposable, sanitized display copy. It is never exported.
export async function previewDocument(source:string) {
  const native=(Document as unknown as NativeParser).parseHTML;
  let document:HTMLElement;
  if(native) {
    document=native.call(Document,source,{sanitizer:{removeElements:blockedTags,removeAttributes:blockedAttrs}}).documentElement;
  } else {
    // Safari and older browsers receive the same isolated display-copy behavior.
    const {default:DOMPurify}=await import('dompurify');
    document=DOMPurify.sanitize(source,{
      WHOLE_DOCUMENT:true,RETURN_DOM:true,ALLOW_DATA_ATTR:false,
      FORBID_TAGS:blockedTags,FORBID_ATTR:blockedAttrs,
    }) as HTMLElement;
  }
  for(const el of document.querySelectorAll('[src]')) {
    const value=el.getAttribute('src')??'';
    const permitted=el.localName==='img' && (/^data:image\/(?:png|jpeg|gif|webp);/i.test(value) || /^https:\/\//i.test(value));
    if(!permitted) {el.removeAttribute('src');el.setAttribute('title','Remote image hidden in preview');}
    else el.setAttribute('referrerpolicy','no-referrer');
  }
  const csp=`default-src 'none'; script-src 'none'; connect-src 'none'; style-src 'unsafe-inline'; img-src data: https:; font-src 'none'; frame-src 'none'; form-action 'none'; base-uri 'none';`;
  return `<!doctype html><html><head><meta http-equiv="Content-Security-Policy" content="${csp}"><meta name="referrer" content="no-referrer"><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:0;overflow-wrap:anywhere}:where(th.inner[role="presentation"]:not([align])){text-align:start}img{max-width:100%}a{cursor:default}[data-preview-active]{outline:2px solid #174f37!important;outline-offset:3px!important;border-radius:3px}</style>${document.querySelector('head')?.innerHTML??''}</head>${document.querySelector('body')?.outerHTML??'<body></body>'}</html>`;
}
