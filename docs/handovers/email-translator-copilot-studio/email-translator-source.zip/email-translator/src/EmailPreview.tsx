import { useEffect, useRef, useState, type ReactNode } from 'react';
import type { Email, Field } from './email';
import { previewDocument } from './preview';

function normalize(text: string) {
  return text.replace(/\s+/g, ' ').trim();
}

function fieldSnippets(field: Field, changes: Record<string, string>, version: 'original' | 'edited'): string[] {
  const edited = version === 'edited' ? changes[field.id] : undefined;
  if (edited !== undefined && edited !== field.original) {
    const parts = field.sections ? edited.replace(/\r\n?/g, '\n').split('\n') : [edited];
    const cleaned = parts.map(normalize).filter(Boolean);
    if (cleaned.length) return cleaned;
  }
  if (field.sections?.length) {
    return field.sections.map(s => normalize(s.original)).filter(Boolean);
  }
  const single = normalize(field.original);
  return single ? [single] : [];
}

function sharedAncestor(a: HTMLElement, b: HTMLElement, root: HTMLElement): HTMLElement {
  let current: HTMLElement | null = a;
  while (current && current !== root) {
    if (current.contains(b)) return current;
    current = current.parentElement;
  }
  return a;
}

function findFieldElement(
  doc: Document,
  email: Email,
  changes: Record<string, string>,
  version: 'original' | 'edited',
  targetId: string
): HTMLElement | null {
  const body = doc.body;
  if (!body) return null;
  const items: { kind: 'text' | 'alt'; text: string; element: HTMLElement }[] = [];
  const walker = doc.createTreeWalker(body, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT);
  let node = walker.nextNode();
  while (node) {
    if (node.nodeType === Node.ELEMENT_NODE) {
      const el = node as HTMLElement;
      if (el.localName === 'img') {
        const alt = normalize(el.getAttribute('alt') ?? '');
        if (alt) items.push({ kind: 'alt', text: alt, element: el });
      }
    } else if (node.nodeType === Node.TEXT_NODE && node.parentElement) {
      const text = normalize(node.nodeValue ?? '');
      if (text) items.push({ kind: 'text', text, element: node.parentElement });
    }
    node = walker.nextNode();
  }

  let cursor = 0;
  for (const field of email.fields) {
    const snippets = fieldSnippets(field, changes, version);
    if (!snippets.length) continue;
    let matchIndex = -1;
    for (let i = cursor; i < items.length; i++) {
      if (items[i].kind === field.kind && items[i].text.includes(snippets[0])) {
        matchIndex = i;
        break;
      }
    }
    if (matchIndex === -1) {
      for (let i = 0; i < cursor; i++) {
        if (items[i].kind === field.kind && items[i].text.includes(snippets[0])) {
          matchIndex = i;
          break;
        }
      }
    }
    if (matchIndex === -1) continue;

    const firstElement = items[matchIndex].element;
    let lastElement = firstElement;
    let nextCursor = items[matchIndex].text === snippets[0] ? matchIndex + 1 : matchIndex;

    if (snippets.length > 1) {
      let searchFrom = matchIndex + 1;
      for (let s = 1; s < snippets.length; s++) {
        for (let i = searchFrom; i < items.length; i++) {
          if (items[i].kind === field.kind && items[i].text.includes(snippets[s])) {
            lastElement = items[i].element;
            searchFrom = i + 1;
            nextCursor = searchFrom;
            break;
          }
        }
      }
    }

    cursor = nextCursor;
    if (field.id === targetId) {
      return firstElement === lastElement ? firstElement : sharedAncestor(firstElement, lastElement, body);
    }
  }
  return null;
}

function scrollPreviewToAsync(element: HTMLElement, behavior: ScrollBehavior, scroller: Window): Promise<void> {
  const bounds = element.getBoundingClientRect();
  // scrollIntoView also scrolls the outer page, taking mobile editors off screen.
  const result = scroller.scrollTo({
    top: scroller.scrollY + bounds.top - Math.max(0, (scroller.innerHeight - bounds.height) / 2),
    left: scroller.scrollX + bounds.left - Math.max(0, (scroller.innerWidth - bounds.width) / 2),
    behavior,
  }) as unknown;
  // Scroll promises originate in the iframe's realm, so instanceof is unreliable.
  if (result && typeof (result as Promise<void>).then === 'function') {
    return Promise.resolve(result as Promise<void>);
  }
  return new Promise(resolve => {
    let timeoutId: ReturnType<typeof setTimeout>;
    const finish = () => {
      clearTimeout(timeoutId);
      scroller.removeEventListener('scrollend', finish);
      scroller.removeEventListener('scroll', onScroll);
      resolve();
    };
    const onScroll = () => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(finish, 100);
    };
    scroller.addEventListener('scrollend', finish, { once: true });
    scroller.addEventListener('scroll', onScroll, { passive: true });
    timeoutId = setTimeout(finish, 100);
  });
}

export function EmailPreview({
  source,
  original,
  email,
  changes,
  selection,
  actions,
}: {
  source: string;
  original: string;
  email: Email;
  changes: Record<string, string>;
  selection: { id: string; seq: number } | null;
  actions: ReactNode;
}) {
  const [version, setVersion] = useState<'original' | 'edited'>('edited');
  const [display, setDisplay] = useState('');
  const [failure, setFailure] = useState('');
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const canvasRef = useRef<HTMLDivElement>(null);
  const [availableWidth, setAvailableWidth] = useState(620);
  const [emailWidth, setEmailWidth] = useState(620);
  const scale = Math.min(1, availableWidth / emailWidth);
  const savedScrollTop = useRef(0);
  const lastScrolledSeq = useRef(0);
  const scrollRequestId = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const observer = new ResizeObserver(entries => {
      setAvailableWidth(Math.max(1, entries[0].contentRect.width));
    });
    observer.observe(canvas);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    let active = true;
    const win = iframeRef.current?.contentWindow;
    if (win) savedScrollTop.current = win.scrollY;
    previewDocument(version === 'edited' ? source : original)
      .then(html => {
        if (active) {
          setDisplay(html);
          setFailure('');
        }
      })
      .catch(() => {
        if (active) {
          setDisplay('');
          setFailure('Preview unavailable. Original HTML is intact.');
        }
      });
    return () => {
      active = false;
    };
  }, [source, original, version]);

  const syncSelection = async (animate: boolean) => {
    const doc = iframeRef.current?.contentDocument;
    const win = iframeRef.current?.contentWindow;
    if (!doc || !win || !selection) return;
    doc.querySelectorAll('[data-preview-active]').forEach(el => el.removeAttribute('data-preview-active'));
    const target = findFieldElement(doc, email, changes, version, selection.id);
    if (!target) return;

    if (!animate) {
      target.setAttribute('data-preview-active', 'true');
      return;
    }

    const requestId = ++scrollRequestId.current;
    const reducedMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
    await scrollPreviewToAsync(target, reducedMotion ? 'auto' : 'smooth', win);
    if (requestId !== scrollRequestId.current) return;
    target.setAttribute('data-preview-active', 'true');
  };

  useEffect(() => {
    if (!selection) return;
    lastScrolledSeq.current = selection.seq;
    void syncSelection(true);
  }, [selection, version]);

  const handleLoad = () => {
    const doc = iframeRef.current?.contentDocument;
    if (doc) setEmailWidth(Math.max(620, doc.documentElement.scrollWidth));
    const win = iframeRef.current?.contentWindow;
    if (win && savedScrollTop.current > 0) {
      win.scrollTo(0, savedScrollTop.current);
    }
    if (selection) {
      const needsScroll = lastScrolledSeq.current !== selection.seq;
      lastScrolledSeq.current = selection.seq;
      void syncSelection(needsScroll);
    }
  };

  return (
    <section className="panel preview-panel" aria-label="Email preview">
      <div className="panel-heading">
        <h2>Preview</h2>
      </div>
      <div className="preview-toolbar">
        <div className="preview-actions">{actions}</div>
        <div className="segmented" role="group" aria-label="Preview version">
          {(['original', 'edited'] as const).map(v => (
            <button key={v} aria-pressed={version === v} className={version === v ? 'active' : ''} onClick={() => setVersion(v)}>
              {v === 'original' ? 'Original' : 'Edited'}
            </button>
          ))}
        </div>
      </div>
      <div className="preview-canvas" ref={canvasRef}>
        {display ? (
          <div className="preview-frame" style={{ width: emailWidth * scale }}>
          <iframe
            ref={iframeRef}
            title="Email display copy"
            sandbox="allow-same-origin"
            referrerPolicy="no-referrer"
            srcDoc={display}
            onLoad={handleLoad}
            style={{ width: emailWidth, height: `${100 / scale}%`, transform: `scale(${scale})` }}
          />
          </div>
        ) : (
          !failure && <p role="status">Loading preview…</p>
        )}
      </div>
      {failure && (
        <div className="error-banner" role="alert">
          {failure}
        </div>
      )}
    </section>
  );
}
