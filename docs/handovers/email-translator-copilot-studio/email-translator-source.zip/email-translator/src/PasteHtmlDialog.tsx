import { useRef, useState } from 'react';
import { ClipboardPaste } from 'lucide-react';
import { MAX_BYTES, looksLikeEmailHtml, readEmail, type Email } from './email';
import { ConfirmDialog, Dialog, openDialog } from './Dialog';

export function PasteHtmlDialog({dirty = false, onLoad}:{dirty?:boolean; onLoad:(email:Email)=>boolean}) {
  const dialog=useRef<HTMLDialogElement>(null);
  const textarea=useRef<HTMLTextAreaElement>(null);
  const [source,setSource]=useState('');
  const [error,setError]=useState('');
  const [pending,setPending]=useState<Email|null>(null);
  const commit=(email:Email)=>{
    if(!onLoad(email))return;
    setPending(null);setSource('');setError('');dialog.current?.close();
  };
  const load=()=>{
    if(!looksLikeEmailHtml(source))return;
    try {
      if(new TextEncoder().encode(source).byteLength>MAX_BYTES) throw new Error('Paste an HTML email smaller than 5 MB.');
      const email=readEmail(source);
      if(dirty){
        setPending(email);
        return;
      }
      commit(email);
    }catch(e){setError(e instanceof Error?e.message:'Could not read this HTML.');textarea.current?.focus();}
  };
  return <>
    <button className="button secondary" type="button" onClick={()=>openDialog(dialog)}><ClipboardPaste size={17} aria-hidden="true"/>Import</button>
    <Dialog dialogRef={dialog} title="Import HTML" onClose={()=>{setPending(null);setError('');}}>
      <form onSubmit={e=>{e.preventDefault();load();}}>
        <label className="visually-hidden" htmlFor="paste-source">HTML source</label>
        <textarea ref={textarea} data-dialog-autofocus autoFocus id="paste-source" name="paste-source" value={source} onChange={e=>{setSource(e.target.value);setError('');}} placeholder="<!doctype html>…" spellCheck={false} autoCorrect="off" autoCapitalize="none" autoComplete="off" aria-invalid={!!error} aria-describedby={error?'paste-error':undefined}/>
        {error&&<p className="field-error" role="alert" id="paste-error">{error}</p>}
        <div className="paste-actions"><button className="button primary" type="submit" disabled={!looksLikeEmailHtml(source)}>Import</button></div>
      </form>
    </Dialog>
    <ConfirmDialog open={pending!==null} title="Replace email?" description="Current translations and language drafts will be discarded." confirmLabel="Replace" onCancel={()=>setPending(null)} onConfirm={()=>{if(pending)commit(pending);}}/>
  </>;
}
