import {describe, expect, it} from 'vitest';
import {draftReducer, emptyDrafts, hasDraftChanges} from './translation-drafts';

describe('language drafts', () => {
  it('keeps translated wording separate when selecting another target and restores it on return', () => {
    let state = draftReducer(emptyDrafts, {type: 'select', language: 'fr'});
    state = draftReducer(state, {type: 'change', id: 'title', value: 'Bonjour'});
    state = draftReducer(state, {type: 'select', language: 'de'});
    expect(state.changes).toEqual({});
    expect(hasDraftChanges(state, [{id: 'title', original: 'Hello'}])).toBe(true);
    state = draftReducer(state, {type: 'change', id: 'title', value: 'Hallo'});
    state = draftReducer(state, {type: 'select', language: 'fr'});
    expect(state.changes.title).toBe('Bonjour');
    state = draftReducer(state, {type: 'select', language: 'de'});
    expect(state.changes.title).toBe('Hallo');
  });
  it('assigns pre-selection manual edits to the first target without duplicating a draft', () => {
    let state = draftReducer(emptyDrafts, {type: 'change', id: 'title', value: 'Bonjour'});
    state = draftReducer(state, {type: 'select', language: 'fr'});
    expect(state.changes.title).toBe('Bonjour');
    expect(state.drafts).toEqual({});
  });
  it('does not overwrite newer manual edits with an older translation result', () => {
    const state = draftReducer(emptyDrafts, {type: 'change', id: 'title', value: 'My wording'});
    expect(draftReducer(state, {type: 'apply', id: 'title', value: 'Bonjour', expected: undefined})).toBe(state);
  });
  it('clears every language draft on reset', () => {
    let state = draftReducer(emptyDrafts, {type: 'select', language: 'fr'});
    state = draftReducer(state, {type: 'change', id: 'title', value: 'Bonjour'});
    state = draftReducer(state, {type: 'select', language: 'de'});
    state = draftReducer(state, {type: 'reset'});
    expect(state).toEqual(emptyDrafts);
    expect(draftReducer(state, {type: 'select', language: 'fr'}).changes).toEqual({});
  });
});
