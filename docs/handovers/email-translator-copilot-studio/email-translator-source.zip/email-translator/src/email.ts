import { parse, parseFragment, type DefaultTreeAdapterMap } from 'parse5';

type Node = DefaultTreeAdapterMap['node'];
type Range = { start: number; end: number; raw: string };
type Section = { original: string; ranges: Range[] };
export type Field = { id: string; original: string; context: string; label: string; ranges: Range[]; kind: 'text' | 'alt'; paired: boolean; sections?: Section[] };
export type Email = { source: string; fields: Field[]; notices: string[]; language?: Range & { value: string } };
type Candidate = Field & { hidden: boolean; tracking?: string; owner?: number; part: number; block?: string; designerBlock?: boolean };
const textTags = new Set(['p','span','a','center','h1','h2','h3','h4','h5','h6','li','td','th','div','strong','em','b','i','u','s','v:textbox']);
const excluded = new Set(['head','style','script','title','textarea','noscript','template','svg','math','iframe','object','xmp']);
const dynamic = /{{[\s\S]*?}}|{%[\s\S]*?%}|\$\{[\s\S]*?}|\[\[[\s\S]*?\]\]/g;
const entities = /&(?:#[xX][0-9a-fA-F]+|#[0-9]+|[A-Za-z][A-Za-z0-9]+);?/g;
function children(n: Node): Node[] { return 'childNodes' in n ? n.childNodes : []; }
function tag(n: Node) { return 'tagName' in n ? n.tagName : ''; }
function attr(n: Node, name: string) { return 'attrs' in n ? n.attrs.find(a => a.name === name)?.value : undefined; }
function allText(n: Node): string { return 'value' in n ? n.value : children(n).map(allText).join(''); }
export function decode(raw: string) { return allText(parseFragment(raw)); }
export function escapeText(value: string) { return value.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#39;'); }
function visible(s: string) { return /[^\p{C}\p{Z}\s]/u.test(s); }
function parts(raw: string) {
  const fixed: { start: number; end: number }[] = [];
  for (const m of raw.matchAll(dynamic)) fixed.push({start:m.index!, end:m.index!+m[0].length});
  // Unknown or unfinished expressions are kept read-only.
  const stripped = raw.replace(dynamic,'');
  if (/{{|}}|{%|%}|\$\{|\[\[|\]\]/.test(stripped)) return [];
  for (const m of raw.matchAll(entities)) if (/[\p{C}\p{Z}\s]/u.test(decode(m[0]))) fixed.push({start:m.index!,end:m.index!+m[0].length});
  for (const m of raw.matchAll(/[\p{Cf}\p{Zl}\p{Zp}\u00a0]/gu)) fixed.push({start:m.index!,end:m.index!+m[0].length});
  fixed.sort((a,b)=>a.start-b.start);
  let end=0;
  const free: Range[]=[];
  const add=(a:number,b:number)=>{
    const chunk=raw.slice(a,b); const core=chunk.trim();
    if (!core || !visible(decode(core))) return;
    const start=a+chunk.indexOf(core);
    free.push({start,end:start+core.length,raw:core});
  };
  for(const f of fixed) { if(f.start>end) add(end,f.start); end=Math.max(end,f.end); }
  add(end,raw.length);return free;
}
export function looksLikeEmailHtml(source: string): boolean {
  return /<(?:html|body|table|div|p|h[1-6])\b/i.test(source);
}
export function readEmail(source: string): Email {
  if (!source.trim() || !looksLikeEmailHtml(source)) throw new Error('Choose an HTML email with readable body content.');
  const candidates: Candidate[]=[];
  const notices=new Set<string>();
  let language: Email['language'];
  const walk=(node:Node, parents:Node[], base:number, hidden:boolean)=>{
    const ancestors=parents.map(tag);
    if (excluded.has(tag(node)) || ancestors.some(t=>excluded.has(t))) return;
    const loc=node.sourceCodeLocation;
    if ('tagName' in node && !hidden && tag(node)==='html') {
      const range=loc && 'attrs' in loc ? loc.attrs?.lang : undefined;
      if(range) {
        const raw=source.slice(base+range.startOffset,base+range.endOffset);
        const m=/^lang\s*=\s*(["'])([\s\S]*)\1$/i.exec(raw);
        if(m) language={start:base+range.startOffset+raw.indexOf(m[2],raw.indexOf(m[1])+1),end:base+range.startOffset+raw.length-1,raw:m[2],value:decode(m[2])};
      }
    }
    if (node.nodeName==='#comment' && loc && !hidden) {
      const raw=source.slice(base+loc.startOffset,base+loc.endOffset);
      const open=/^<!--\[if\b[^>]*>/i.exec(raw);
      const close=/<!\[endif\]-->$/i.exec(raw);
      if(open && close) {
        const content=raw.slice(open[0].length,close.index);
        walk(parseFragment(content,{sourceCodeLocationInfo:true}),parents,base+loc.startOffset+open[0].length,true);
      }
      return;
    }
    const nearest=[...parents].reverse();
    const link=nearest.find(n=>['a','v:shape','v:roundrect'].includes(tag(n)));
    const tracking=link && attr(link,'data-msdyn-tracking-id');
    const owner=link?.sourceCodeLocation?.startOffset;
    const designerBlock=nearest.find(n=>attr(n,'data-editorblocktype')?.toLowerCase()==='text');
    const textBlock=designerBlock??nearest.find(n=>['p','h1','h2','h3','h4','h5','h6','li','center','div','td','th'].includes(tag(n)));
    const blockStart=textBlock?.sourceCodeLocation?.startOffset;
    if(node.nodeName==='#text' && loc && ancestors.some(t=>textTags.has(t))) {
      const raw=source.slice(base+loc.startOffset,base+loc.endOffset);
      if(raw.includes('<')) { notices.add('Some complex markup is read-only.'); return; }
      const label=ancestors.some(t=>/^h[1-6]$/.test(t))?'Heading':link?'Link / button':ancestors.includes('li')?'List item':'Body text';
      parts(raw).forEach((p,part)=>candidates.push({id:`text-${base+loc.startOffset+p.start}`,kind:'text',original:decode(p.raw),context:decode(raw).trim(),label,
        ranges:[{...p,start:base+loc.startOffset+p.start,end:base+loc.startOffset+p.end}],paired:false,hidden,tracking,owner:owner===undefined?undefined:base+owner,part,
        block:blockStart===undefined?undefined:`${hidden?'outlook':'normal'}-${base+blockStart}`,designerBlock:!!designerBlock}));
    }
    if(tag(node)==='img' && loc && 'attrs' in loc && loc.attrs?.alt && !hidden) {
      const r=loc.attrs.alt;
      const raw=source.slice(base+r.startOffset,base+r.endOffset);
      const m=/^alt\s*=\s*(["'])([\s\S]*)\1$/i.exec(raw);
      if(m && m[2].trim() && !/{{|{%|\$\{|\[\[/.test(m[2])) {
        const offset=base+r.startOffset+raw.indexOf(m[1])+1;
        // Image alt values with fixed spacing or unknown counterpart patterns remain protected.
        if(parts(m[2]).length===1 && parts(m[2])[0].raw===m[2]) candidates.push({id:`alt-${offset}`,kind:'alt',label:'Image description',original:decode(m[2]),context:decode(m[2]),ranges:[{start:offset,end:offset+m[2].length,raw:m[2]}],paired:false,hidden:false,part:0});
      }
    }
    for(const child of children(node)) walk(child,[...parents,node],base,hidden);
  };
  const bom=source.startsWith('\ufeff')?1:0;
  walk(parse(source.slice(bom),{sourceCodeLocationInfo:true}),[],bom,false);
  const used=new Set<Candidate>(); const fields:Candidate[]=[];
  const trackings=new Map<string,Candidate[]>();
  for(const c of candidates) if(c.tracking) trackings.set(c.tracking,[...(trackings.get(c.tracking)??[]),c]);
  const ambiguousText=new Set<string>();
  const ambiguousTracking=new Set<string>();
  for(const c of candidates.filter(c=>c.hidden)) {
    const siblings=c.tracking?trackings.get(c.tracking)??[]:[];
    const owners=new Set(siblings.map(s=>s.owner));
    const matches=siblings.filter(s=>s.part===c.part && s.context===c.context && s.original===c.original && s.hidden!==c.hidden);
    if(owners.size===2 && matches.length===1) {
      const other=matches[0];
      other.ranges.push(...c.ranges);other.paired=true;used.add(c);
    } else { ambiguousText.add(c.context); if(c.tracking) ambiguousTracking.add(c.tracking); notices.add('Unmatched Outlook text is read-only.'); }
  }
  // Alt edits in exported Outlook image wrappers cannot yet be mapped safely.
  const hasConditionalImages=/<!--\[if\b[\s\S]*?<img\b/i.test(source);
  for(const c of candidates) {
    if(used.has(c) || c.hidden || ambiguousText.has(c.context) || c.tracking && ambiguousTracking.has(c.tracking)) continue;
    if(c.kind==='alt' && hasConditionalImages) { notices.add('Image descriptions with Outlook copies are read-only.');continue; }
    fields.push(c);
  }
  const grouped=groupBlocks(fields);
  grouped.sort((a,b)=>a.ranges[0].start-b.ranges[0].start);
  const ranges=grouped.flatMap(f=>f.ranges).sort((a,b)=>a.start-b.start);
  if(ranges.some((r,i)=>i>0 && ranges[i-1].end>r.start)) throw new Error('Overlapping text blocks detected.');
  if(!grouped.length) notices.add('No editable text found.');
  return {source,fields:grouped,notices:[...notices],language};
}
function groupBlocks(fields:Candidate[]):Field[] {
  const blocks=new Map<string,Candidate[]>();
  for(const field of fields) if(field.kind==='text' && field.block) blocks.set(field.block,[...(blocks.get(field.block)??[]),field]);
  const consumed=new Set<Candidate>();const result:Field[]=[];
  for(const field of fields) {
    if(consumed.has(field))continue;
    const members=field.block?blocks.get(field.block)??[]:[];
    // Keep token-separated runs and Outlook-linked controls under their existing guards.
    if(field.kind!=='text' || members.length<2 || members.some(f=>f.paired || f.original!==f.context)) {result.push(field);continue;}
    members.sort((a,b)=>a.ranges[0].start-b.ranges[0].start);
    const sections=members.map(f=>({original:f.original.replace(/\s+/g,' ').trim(),ranges:f.ranges}));
    const original=sections.map(s=>s.original).join('\n');
    result.push({...field,original,context:original,label:field.designerBlock?'Text block':field.label,sections,ranges:sections.flatMap(s=>s.ranges)});
    members.forEach(f=>consumed.add(f));
  }
  return result;
}
export function exportEmail(email:Email, changes:Record<string,string>, language?:string) {
  const edits:{start:number;end:number;replacement:string}[]=[];
  for(const field of email.fields) {
    const value=changes[field.id];
    if(value===undefined || value===field.original) continue;
    if(!visible(value)) throw new Error('Translation cannot be empty. Use Reset to restore original.');
    if(/\{\{|\}\}|\{%|%\}|\$\{|\[\[|\]\]|[\p{Cf}\p{Zl}\p{Zp}]/u.test(value)) throw new Error('Enter plain text only (no template tags or invisible characters).');
    const sections=field.sections??[{original:field.original,ranges:field.ranges}];
    const values=field.sections?value.replace(/\r\n?/g,'\n').split('\n'):[value];
    if(values.length!==sections.length) throw new Error(`Keep all ${sections.length} sections on separate lines.`);
    for(let i=0;i<sections.length;i++) {
      if(!visible(values[i])) throw new Error('Each text section needs text. Use Reset to restore original.');
      if(values[i]===sections[i].original)continue;
      for(const range of sections[i].ranges) {
        if(email.source.slice(range.start,range.end)!==range.raw) throw new Error('The original source no longer matches this text block. Reload the email.');
        edits.push({...range,replacement:escapeText(values[i])});
      }
    }
  }
  if(language && email.language && language!==email.language.value) {
    if(!/^[A-Za-z]{2,8}(?:-[A-Za-z0-9]{1,8})*$/.test(language)) throw new Error('Choose a valid language.');
    edits.push({...email.language,replacement:language});
  }
  edits.sort((a,b)=>b.start-a.start);
  let result=email.source;
  for(const edit of edits) result=result.slice(0,edit.start)+edit.replacement+result.slice(edit.end);
  return result;
}
export const MAX_BYTES=5*1024*1024;
export async function readFile(file:File) {
  if(file.size>MAX_BYTES) throw new Error('Choose an HTML file smaller than 5 MB.');
  const bytes=await file.arrayBuffer();
  let source:string;
  try { source=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(bytes); }
  catch { throw new Error('This prototype reads UTF-8 HTML. The selected file uses another encoding.'); }
  return readEmail(source);
}
